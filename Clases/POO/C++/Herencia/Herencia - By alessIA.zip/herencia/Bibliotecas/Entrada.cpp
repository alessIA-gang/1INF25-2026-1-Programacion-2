//
// Created by isabe on 27/05/2026.
//

#include "Entrada.h"

#include <cstring>

Entrada::Entrada() {
    picante = false;
}

bool Entrada::is_picante() const {
    return picante;
}

void Entrada::set_picante(bool picante) {
    this->picante = picante;
}

void Entrada::leeentrada(ifstream &arch) {
    //142,E,Quesadillas,5.5,sin picante
    char cad[15];
    leeproducto(arch);
    arch.getline(cad, 17);
    if (strcmp(cad, "picante") == 0) picante = true;
}

void Entrada::operator=(Entrada &e) {
    char cad[15];
    set_price(e.get_price());
    e.get_nombre(cad);
    set_nombre(cad);
}

void Entrada::imprimeEntrada(ofstream &arch) {
    imprimeProducto(arch);
    if (picante)arch << "Picante"<<endl;
    else arch << "Sin picante"<<endl;
}

