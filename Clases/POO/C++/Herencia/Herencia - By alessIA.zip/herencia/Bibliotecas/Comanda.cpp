//

// Created by isabe on 26/05/2026.

//

#include "Comanda.h"
#include <iostream>
#include "Entrada.h"
using namespace std;

Comanda::Comanda() {
    id = 0;
    cantidad_bebidas = 0;
    hora_atencion = 0;
    hora_servicio = 0;
    tiempo_de_preparacion = 0;
    total = 0;
}

int Comanda::get_id() const {
    return id;
}

Comanda::~Comanda() {
    delete[] entradas;
}

void Comanda::set_id(int id) {
    this->id = id;
}

int Comanda::get_cantidad_bebidas() const {
    return cantidad_bebidas;
}

void Comanda::set_cantidad_bebidas(int cantidad_bebidas) {
    this->cantidad_bebidas = cantidad_bebidas;
}

int Comanda::get_hora_atencion() const {
    return hora_atencion;
}

void Comanda::set_hora_atencion(int hora_atencion) {
    this->hora_atencion = hora_atencion;
}

int Comanda::get_hora_servicio() const {
    return hora_servicio;
}

void Comanda::set_hora_servicio(int hora_servicio) {
    this->hora_servicio = hora_servicio;
}

int Comanda::get_tiempo_de_preparacion() const {
    return tiempo_de_preparacion;
}

void Comanda::set_tiempo_de_preparacion(int tiempo_de_preparacion) {
    this->tiempo_de_preparacion = tiempo_de_preparacion;
}

double Comanda::get_total() const {
    return total;
}

void Comanda::set_total(double total) {
    this->total = total;
}

int Comanda::get_cantidad_platos() const {
    return cantidad_platos;
}

void Comanda::set_cantidad_platos(int cantidad_platos) {
    this->cantidad_platos = cantidad_platos;
}

void Comanda::leecomanda(char tipo, ifstream &arch) {
    if (tipo == 'B') {
        bebidas[cantidad_bebidas].leebebidas(arch);
        cantidad_bebidas++;
    } else if (tipo == 'P') {
        platos_fondo[cantidad_platos].leeplatos(arch);
        cantidad_platos++;
    } else if (tipo == 'E') {
        if (entradas == nullptr)
            entradas = new Entrada[20];
        int i;
        for (i = 0; entradas[i].get_price() != 0; i++);
        entradas[i].leeentrada(arch);
    }
}

bool Comanda::isnull() {
    if (entradas == nullptr) return true;
    return false;
}

int Comanda::cuentaentradas() {
    if (entradas != nullptr) {
        int i;
        for (i = 0; entradas[i].get_price() != 0; i++);
        return i;
    }
    return 0;
}

void Comanda::recortarEntradas() {
    int n = cuentaentradas();
    Entrada *aux = new Entrada[n + 1];
    for (int i = 0; i < n; i++)
        aux[i] = entradas[i];
    delete[] entradas;
    entradas = aux;
}

void Comanda::imprimeComanda(ofstream &arch) {
    if (cantidad_bebidas != 0) arch << "-----BEBIDAS-----" << endl;
    for (int i = 0; i < cantidad_bebidas; i++) {
        arch << "Bebida " << i + 1 << ":" << endl;
        bebidas[i].imprimeBebida(arch);
        arch << endl;
    }
    if (cantidad_platos != 0) arch << "-----PLATOS-----" << endl;
    for (int i = 0; i < cantidad_platos; i++) {
        arch << "Plato " << i + 1 << ":" << endl;
        platos_fondo[i].imprimePlato(arch);
        arch << endl;
    }
    if (cuentaentradas() != 0) arch << "-----ENTRADAS-----" << endl;
    for (int i = 0; i < cuentaentradas(); i++) {
        arch << "Entrada " << i + 1 << ":" << endl;
        entradas[i].imprimeEntrada(arch);
        arch << endl;
    }
    for (int i = 0; i < 80; i++) {
        arch << '=';
    }
    arch << endl;
}
