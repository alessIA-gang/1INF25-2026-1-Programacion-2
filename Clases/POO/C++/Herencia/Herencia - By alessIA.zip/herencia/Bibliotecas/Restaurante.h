//
// Created by isabe on 26/05/2026.
//

#ifndef HERENCIA_RESTAURANTE_H
#define HERENCIA_RESTAURANTE_H

#include "Comanda.h"
#include <fstream>
using namespace std;
class Restaurante {
private:
    Comanda comandas[100];
    int cant_comandas;
    void recorte();
    void buscayasigna(int id);
public:
    int get_cant_comandas() const;

    void set_cant_comandas(int cant_comandas);

    Restaurante();
    void cargar_comandas();
    void imprimir_comandas();
};


#endif //HERENCIA_RESTAURANTE_H