//
// Created by cueva.r on 27/05/2026.
//

#include "PlatoFondo.h"

PlatoFondo::PlatoFondo() {
    proteina = nullptr;
}

PlatoFondo::~PlatoFondo() {
    if (proteina != nullptr)
        delete proteina;
}


int *PlatoFondo::get_proteina() const {
    return proteina;
}

void PlatoFondo::set_proteina(int *proteina) {
    this->proteina = proteina;
}

void PlatoFondo::leeplatos(ifstream &arch) {
    leeproducto(arch);
    char c;
    int c0, c1, c2, c3; //mid XD
    // for (int i=0;i<4;i++) {
    //     arch >> proteina[i]>>c;
    // }
    arch >> c0 >> c >> c1 >> c >> c2 >> c >> c3;
    proteina = new int[4]{};
    proteina[0] = c0;
    proteina[1] = c1;
    proteina[2] = c2;
    proteina[3] = c3;
}

void PlatoFondo::imprimePlato(ofstream &arch) {
    imprimeProducto(arch);
    arch << "Proteína: ";
    if (proteina[0] == 1) arch << "Pollo" << endl;
    else if (proteina[1] == 1) arch << "Carne " << endl;
    else if (proteina[2] == 1) arch << "Pescado " << endl;
    else if (proteina[3] == 1) arch << "Lácteos " << endl;
    else arch<<"No tiene proteínas"<<endl;
}
