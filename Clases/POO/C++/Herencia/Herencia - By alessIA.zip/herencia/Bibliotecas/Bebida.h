//
// Created by isabe on 26/05/2026.
//

#ifndef HERENCIA_BEBIDA_H
#define HERENCIA_BEBIDA_H

#include "Producto.h"
#include <fstream>
using namespace std;

class Bebida : public Producto {
private:
    char *tamaño;

public:
    Bebida();

    virtual ~Bebida();

    void get_tamaño(char *);

    void set_tamaño(const char *);
    void leebebidas(ifstream&srch);
    void imprimeBebida(ofstream&arch);
};


#endif //HERENCIA_BEBIDA_H
