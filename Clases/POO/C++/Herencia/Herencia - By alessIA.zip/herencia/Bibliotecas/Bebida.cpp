//
// Created by isabe on 26/05/2026.
//

#include "Bebida.h"
#include <cstring>

Bebida::Bebida() {
    tamaño=nullptr;
}
 Bebida::~Bebida() {
     if (tamaño!=nullptr)delete tamaño;
 }

void Bebida::get_tamaño(char* cad) {
    if (this->tamaño==nullptr)cad[0]=0;
    else
        strcpy(cad,this->tamaño);
}

void Bebida::set_tamaño(const char* cad) {
    if (this->tamaño!=nullptr)
        delete this->tamaño;
    this->tamaño=new char[strlen(cad)+1];
    strcpy(this->tamaño,cad);
}

void Bebida::leebebidas(ifstream &arch) {
    char nombre[50];
    leeproducto(arch);
    arch.getline(nombre,50);
    set_tamaño(nombre);

}

void Bebida::imprimeBebida(ofstream &arch) {
    imprimeProducto(arch);
    arch<<"Tamaño: "<<tamaño<<endl;
}
