//
// Created by isabe on 27/05/2026.
//

#ifndef HERENCIA_ENTRADA_H
#define HERENCIA_ENTRADA_H
#include "Producto.h"

class Entrada:public Producto {
public:
    bool is_picante() const;
    void set_picante(bool picante);
    Entrada();
    void leeentrada(ifstream &arch);
    void operator =(Entrada &e);
    void imprimeEntrada(ofstream &arch);
private:
    bool picante;


};


#endif //HERENCIA_ENTRADA_H