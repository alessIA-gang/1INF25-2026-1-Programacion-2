//
// Created by isabe on 26/05/2026.
//

#include "Producto.h"
#include <cstring>

Producto::Producto() {
    nombre=nullptr;
    precio=0;
}
Producto::~Producto() {
    if(nombre!=nullptr)
    delete nombre;
}
double Producto::get_price() const {
    return precio;
}

void Producto::set_price(double price) {
    this->precio = price;
}

void Producto::get_nombre(char* cad) {
    if (this->nombre==nullptr)cad[0]=0;
    else
        strcpy(cad,this->nombre);
}

void Producto::set_nombre(const char* cad) {
    if (this->nombre!=nullptr)
        delete this->nombre;
    this->nombre=new char[strlen(cad)+1];
    strcpy(this->nombre,cad);
}

void Producto::leeproducto(ifstream &arch) {
    char nombre[25],c;
    arch.getline(nombre,50,',');
    set_nombre(nombre);
    arch>>precio>>c;
}

void Producto::imprimeProducto(ofstream &arch) {
    arch<<"Nombre: "<<nombre<<endl<<"Precio: S/. "<<precio<<endl;
}

