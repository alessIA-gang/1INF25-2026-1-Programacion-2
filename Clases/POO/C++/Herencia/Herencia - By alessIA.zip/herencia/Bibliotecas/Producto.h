//
// Created by isabe on 26/05/2026.
//

#ifndef HERENCIA_PRODUCTO_H
#define HERENCIA_PRODUCTO_H
#include <fstream>
using namespace std;


class Producto {
private:
    char *nombre;
    double precio;

public:
    Producto();

    virtual ~Producto();

    double get_price() const;

    void set_price(double price);

    void get_nombre(char *);

    void set_nombre(const char *);

    void leeproducto(ifstream &arch);

    void imprimeProducto(ofstream &arch);
};


#endif //HERENCIA_PRODUCTO_H
