//
// Created by isabe on 26/05/2026.
//

#include "Restaurante.h"
#include "Comanda.h"

#include <iostream>
#include <iomanip>

Restaurante::Restaurante() {
    cant_comandas = 0;
}

void Restaurante::cargar_comandas() {
    int id, hA, mA, hS, mS;
    char c;
    ifstream arch("ArchivosDeEntrada/atenciones.csv", ios::in);
    if (not arch) {
        cout << "Error atenciones" << endl;
        exit(1);
    }
    while (true) {
        //738,11:40,12:43
        arch >> id;
        if (arch.eof())break;
        comandas[cant_comandas].set_id(id);
        arch >> c >> hA >> c >> mA >> c >> hS >> c >> mS;
        comandas[cant_comandas].set_hora_atencion(hA * 60 + mA);
        comandas[cant_comandas].set_hora_atencion(hS * 60 + mS);
        buscayasigna(id);
        cant_comandas++;
    }
    recorte();
}

void Restaurante::imprimir_comandas() {
    ofstream arch("reporte.txt",ios::out);
    if (not arch) {
        cout<<"Error"<<endl;
        exit(1);
    }
    arch<<setw(52)<<"COMANDAS DEL RESTAURANTE"<<endl;
    for (int i = 0; i < 80; i++) {
        arch<<'=';
    }
    arch<<endl;
    for (int i=0; i<cant_comandas; i++) {
        arch<<setw(43)<<"COMANDA "<<i+1<<" :"<<endl;
        for (int i = 0; i < 80; i++) {
            arch<<'=';
        }
        arch<<endl;
        comandas[i].imprimeComanda(arch);
    }
}


void Restaurante::buscayasigna(int id) {
    ifstream arch("ArchivosDeEntrada/comandas.csv", ios::in);
    int idCom;
    char c, tipo;
    if (not arch) {
        cout << "Error comandas" << endl;
        exit(1);
    }
    //142,B,Cafe,2,grande
    // 142,B,Agua Mineral,2.5,pequeno

    while (true) {
        arch >> idCom;
        if (arch.eof())break;
        if (idCom == id) {
            arch >> c >> tipo >> c;
            comandas[cant_comandas].leecomanda(tipo, arch);
        } else while (arch.get() != '\n');
    }
}


void Restaurante::recorte() {
    for (int i = 0; i < cant_comandas; i++) {
        if (not comandas[i].isnull()) {
            comandas[i].recortarEntradas();
        }
    }
}

int Restaurante::get_cant_comandas() const {
    return cant_comandas;
}

void Restaurante::set_cant_comandas(int cant_comandas) {
    this->cant_comandas = cant_comandas;
}
