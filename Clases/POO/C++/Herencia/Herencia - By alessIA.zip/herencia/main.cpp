/* 
 * Archivo:   main.cpp
 * Autor: *** 20241238, Alessia Isabella Gastello Anglas ***
 * Fecha y Hora: *** xx/xx/25 xx:xx ***
 * 
 * ==========================================================================
 * descprición
 * ==========================================================================
 */

#include <iostream>
#include <iomanip>
#include "Bibliotecas/Restaurante.h"
using namespace std;

int main(int argc, char **argv) {
    Restaurante restaurante;
    restaurante.cargar_comandas();
    restaurante.imprimir_comandas();
    return 0;
}