import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PlataformaStreaming {
    private ArrayList<Suscripcion> suscripciones;
    private ArrayList<Usuario>usuarios;
    private Scanner arch;

    public PlataformaStreaming(String nombre)throws FileNotFoundException {
        suscripciones=new ArrayList<>();
        usuarios=new ArrayList<>();
        arch=new Scanner(new File(nombre));
    }

    public void cargarDatos(){
        //cargarCanales
        //bypass de canales borrar al desarrollar
        while(arch.hasNext()){
            String aux;
            aux=arch.next();
            if(aux.compareTo("FIN")==0)break;
        }
        cargarUsuarios();
        cargarSuscriciones();
    }
    private void cargarUsuarios(){
        while(true){
            Usuario aux=new Usuario();
            if(!aux.leer(arch)) break;
            usuarios.add(aux);
        }
    }
    private void cargarSuscriciones(){
        while(arch.hasNext()){
            Suscripcion aux;
            String tipo=arch.next();
            if(tipo.compareTo("BASICA")==0)
                aux=new SuscripcionBasica();
            else
                if(tipo.compareTo("PREMIUM")==0)
                    aux=new SuscripcionPremium();
                else
                    aux= new SuscripcionVip();
            aux.leer(arch);
            suscripciones.add(aux);
        }
    }


}
