import java.util.Scanner;

public abstract class Suscripcion extends Registro {
    private int idUsuario;
    private int idCanal;
    //usuario
    //canal
    public int getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
    public int getIdCanal() {
        return idCanal;
    }
    public void setIdCanal(int idCanal) {
        this.idCanal = idCanal;
    }
    @Override
    public boolean leer(Scanner arch){
        if(arch.hasNext()) {
            idUsuario = arch.nextInt();
            idCanal = arch.nextInt();
            return true;
        }
        return false;
    }
    @Override
    public void imprimir(){
        //despues
    }
    public abstract String getTipo();
    public abstract double calcularprecio();
}
