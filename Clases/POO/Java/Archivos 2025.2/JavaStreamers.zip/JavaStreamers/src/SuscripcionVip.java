public class SuscripcionVip extends Suscripcion {

    @Override
    public String getTipo(){
        return "VIP";
    }
    @Override
    public double calcularprecio(){
        return 100.00;
    }

}
