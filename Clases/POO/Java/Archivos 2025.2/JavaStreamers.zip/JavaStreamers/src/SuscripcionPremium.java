public class SuscripcionPremium extends Suscripcion {

    @Override
    public String getTipo(){
        return "PREMIUM";
    }
    @Override
    public double calcularprecio(){
        return 80.00;
    }


}
