import java.util.ArrayList;
import java.util.Scanner;

public class Usuario extends Registro {
    private int id;
    private String nombreCompleto;
    private int dni;
    private int edad;
    private String fechaNacimiento;
    private String ciudad;
    private String telefono;
    private String email;
    private String ocupacion;
    private ArrayList<Suscripcion>suscripciones ;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getOcupacion() {
        return ocupacion;
    }

    public void setOcupacion(String ocupacion) {
        this.ocupacion = ocupacion;
    }
    @Override
    public boolean leer(Scanner arch){
            if(!arch.hasNextInt()) {
                arch.next();
                return false;
            }
            id=arch.nextInt();
            nombreCompleto=arch.next();
            dni=arch.nextInt();
            edad=arch.nextInt();
            ciudad=arch.next();
            fechaNacimiento=arch.next();
            telefono=arch.next();
            email= arch.next();
            ocupacion =arch.next();
            return true;
    }

    @Override
    public void imprimir() {

    }

}
