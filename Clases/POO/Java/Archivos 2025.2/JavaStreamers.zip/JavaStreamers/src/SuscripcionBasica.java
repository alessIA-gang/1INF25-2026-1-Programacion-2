public class SuscripcionBasica extends Suscripcion{

    @Override
    public String getTipo(){
        return "BASICA";
    }
    @Override
    public double calcularprecio(){
        return 50.00;
    }

}
