import java.util.Scanner;

public class Bebida extends Producto{
    private String tamano;

    public String getTamano() {
        return tamano;
    }

    public void setTamano(String tamano) {
        this.tamano = tamano;
    }
    @Override
    public String tiposoy(){
        return "B";
    }

    @Override
    public void lee(Scanner arch){
        super.lee(arch);
        tamano=arch.next();
    }
    @Override
    public void imprime(){
        super.imprime();
        System.out.println(tamano);
    }

}
