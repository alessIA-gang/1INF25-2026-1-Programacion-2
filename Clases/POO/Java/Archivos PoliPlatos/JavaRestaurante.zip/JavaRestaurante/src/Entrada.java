import java.util.Scanner;

public class Entrada extends Producto {
    private boolean picante;

    public Entrada(){
        picante=false;
    }

    public boolean isPicante() {
        return picante;
    }

    public void setPicante(boolean picante) {
        this.picante = picante;
    }

    @Override
    public String tiposoy(){
        return "E";
    }

    @Override
    public void lee(Scanner arch){
        String picapica;
        super.lee(arch);
        picapica=arch.next();
        if(picapica.compareTo("picante")==0)
            picante=true;
    }
    @Override
    public void imprime(){
        super.imprime();
        if(picante)
            System.out.println("Picante");
        else
            System.out.println("No picante");
    }
}
