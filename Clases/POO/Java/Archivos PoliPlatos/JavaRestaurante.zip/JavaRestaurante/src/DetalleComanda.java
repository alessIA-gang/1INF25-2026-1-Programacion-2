import java.util.Scanner;

public class DetalleComanda {
    private int id;
    private Producto pedido;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public void leecomanda(Scanner arch){
        String tipo;
        id=arch.nextInt();
        tipo=arch.next();
        if(tipo.compareTo("E")==0)
            pedido = new Entrada();
        else
            if(tipo.compareTo("P")==0)
                pedido = new PlatoFondo();
            else
                pedido = new Bebida();
        pedido.lee(arch);
    }
    public void imprimecomanda(){
        System.out.println("Id: "+id);
        System.out.println("Tipo :"+pedido.tiposoy());
        pedido.imprime();
    }
}
