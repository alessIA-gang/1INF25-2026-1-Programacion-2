public class Profesor {
}
