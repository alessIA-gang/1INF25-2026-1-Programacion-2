#include <iostream>
#include <cstring>
using namespace  std;

int main() {
    int *a;
    char *c;
    void *p;
    a = new int;
    c = new char[20];
    *a = 20;
    p = a;
    cout << *a << endl;
    cout << ((int*)p)[0]<<endl;
    cout << *(int*)p << endl;
    strcpy(c, "Hola soy void");
    cout << c << endl;
    p = c;
    cout << (char*)p << endl;

    return 0;
}