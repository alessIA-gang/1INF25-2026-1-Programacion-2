/* 
 * Proyecto: EX01_Preg01_2022_1
 * Archivo:  ClientesPreg1.cpp
 * Autor:    J. Miguel Guanira E.
 *
 * Created on 15 de mayo de 2022, 10:35 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
#include <cstring>
#include "ClientesPreg1.h"

void leerRegistroMIG(ifstream &,int **&,char **&);
void aumentarEspaciosMIG(int ***&, char***&,int &, int &);
void imprimeCliente(int,int **, char **,ofstream &);
void imprimePedidos(int *, ofstream &);
void fecha_a_ddmmaa(int ,int&,int&,int&);

void CargaDeClientes (int ***&cli_DniTelPed, char***&cli_NombreCategoria,
                      const char*nombArch ){    
    int nd=0, cap=0, **regDTP;
    char **regNC;
    ifstream arch(nombArch, ios::in);
    if (not arch.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    cli_DniTelPed = nullptr;
    cli_NombreCategoria = nullptr;
    while(true){
        leerRegistroMIG(arch,regDTP,regNC);
        if(arch.eof())break;
        if(nd == cap) 
            aumentarEspaciosMIG(cli_DniTelPed, cli_NombreCategoria,nd, cap);
        cli_DniTelPed[nd] = nullptr;
        cli_DniTelPed[nd-1] = regDTP;
        cli_NombreCategoria[nd] = nullptr;
        cli_NombreCategoria[nd-1] = regNC;
        nd++;
    }   
}

void leerRegistroMIG(ifstream &arch,int **&regDTP,char **&regNC){
    int dni,*dniP,*tel,tam;
    char cad[200], *nomb, *cat;
    
    arch >>dni;
    if(arch.eof())return;
    arch.get();
    dniP = new int;
    *dniP = dni;
    arch.getline(cad,200,',');
    tam = strlen(cad);
    cat = new char;
    if(cad[tam-2]==' '){ 
        *cat = cad[tam-1];
        cad[tam-2] = 0;
        tam -= 2;
    }
    else *cat='-';
    nomb = new char[tam+1];
    strcpy(nomb,cad);
    tel = new int;
    arch >> *tel;
    regDTP = new int* [3];
    regNC = new char* [2];
    regDTP[0] = dniP;
    regDTP[1] = tel;
    regDTP[2] = nullptr;
    regNC[0] = nomb;
    regNC[1] = cat;
}

void aumentarEspaciosMIG(int ***&cli_DniTelPed, char***&cli_NombreCategoria,
                         int &nd, int &cap){
    int ***auxDT;
    char ***auxNC;
    cap +=5;
    if(cli_DniTelPed == nullptr){
        cli_DniTelPed = new int **[cap];
        cli_DniTelPed[0] = nullptr;
        cli_NombreCategoria = new char **[cap];
        cli_NombreCategoria[0] = nullptr;
        nd = 1;
    }
    else {
        auxDT = new int**[cap];
        auxNC = new char**[cap];
        for(int i=0; i<nd; i++){
            auxDT[i] = cli_DniTelPed[i];
            auxNC[i] = cli_NombreCategoria[i];
        }
        delete cli_DniTelPed;
        delete cli_NombreCategoria;
        cli_DniTelPed = auxDT;
        cli_NombreCategoria = auxNC;
    }

}

void PruebaDeClientes(int ***cli_DniTelPed,char ***cli_NombreCategoria,
                       const char*nombArch){
    ofstream arch(nombArch, ios::out);
    if (not arch.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    
      
    for(int i=0; cli_DniTelPed[i];i++){
        arch<<endl<<left<<setw(3)<<"No"<<setw(10)<<"DNI"
            <<setw(45)<< "NOMBRE"
            <<setw(4)<< "CAT" 
            <<right<<setw(14)<<"TELEFONO"<<endl;
        imprimeCliente(i+1,cli_DniTelPed[i],cli_NombreCategoria[i],arch);
        
    }
}
void imprimeCliente(int i, int **cli_DniTelPed, char **cli_NombreCategoria, 
                    ofstream &arch){
    arch<<left<<setw(3)<<i<<setw(10)<<*cli_DniTelPed[0]
        <<setw(45)<< cli_NombreCategoria[0]
        <<setw(4)<< *cli_NombreCategoria[1] 
        <<right<<setw(14)<<*cli_DniTelPed[1]<<endl; 
    if(cli_DniTelPed[2])
        imprimePedidos(cli_DniTelPed[2], arch);
}

void imprimePedidos(int *cli_DniTelPed, ofstream &arch){
    int dd,mm,aa;
    arch.precision(2);
    arch<<fixed;
    arch<<right<<setw(20)<<"Fecha"<<setw(10)<<"Cod Pro"<<setw(10)<<"Cant"<<endl;
    for(int i=0; cli_DniTelPed[i]; i+=3){
        fecha_a_ddmmaa(cli_DniTelPed[i],dd,mm,aa);
        arch<<right<<setw(10)<<' ';
        arch.fill('0');
        arch<<setw(2)<<dd<<'/'<<setw(2)<<mm<<'/'<<setw(4)<<aa;
        arch.fill(' ');
        arch<<setw(10)<<cli_DniTelPed[i+1]<<setw(10)
            <<(double)cli_DniTelPed[i+2]/100<<endl;
    }
}

void fecha_a_ddmmaa(int fecha,int&dd,int&mm,int&aa){
    aa = fecha/10000;
    fecha %= 10000;
    mm = fecha/100;
    dd = fecha%100;
}