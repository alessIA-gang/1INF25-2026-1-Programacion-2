#
# Generated - do not edit!
#
# NOCDDL
#
CND_BASEDIR=`pwd`
CND_BUILDDIR=build
CND_DISTDIR=dist
# Debug configuration
CND_PLATFORM_Debug=MinGW-Windows
CND_ARTIFACT_DIR_Debug=dist/Debug/MinGW-Windows
CND_ARTIFACT_NAME_Debug=ex01_preg01_2022_1
CND_ARTIFACT_PATH_Debug=dist/Debug/MinGW-Windows/ex01_preg01_2022_1
CND_PACKAGE_DIR_Debug=dist/Debug/MinGW-Windows/package
CND_PACKAGE_NAME_Debug=ex01preg0120221.tar
CND_PACKAGE_PATH_Debug=dist/Debug/MinGW-Windows/package/ex01preg0120221.tar
# Release configuration
CND_PLATFORM_Release=MinGW-Windows
CND_ARTIFACT_DIR_Release=dist/Release/MinGW-Windows
CND_ARTIFACT_NAME_Release=ex01_preg01_2022_1
CND_ARTIFACT_PATH_Release=dist/Release/MinGW-Windows/ex01_preg01_2022_1
CND_PACKAGE_DIR_Release=dist/Release/MinGW-Windows/package
CND_PACKAGE_NAME_Release=ex01preg0120221.tar
CND_PACKAGE_PATH_Release=dist/Release/MinGW-Windows/package/ex01preg0120221.tar
#
# include compiler specific variables
#
# dmake command
ROOT:sh = test -f nbproject/private/Makefile-variables.mk || \
	(mkdir -p nbproject/private && touch nbproject/private/Makefile-variables.mk)
#
# gmake command
.PHONY: $(shell test -f nbproject/private/Makefile-variables.mk || (mkdir -p nbproject/private && touch nbproject/private/Makefile-variables.mk))
#
include nbproject/private/Makefile-variables.mk
