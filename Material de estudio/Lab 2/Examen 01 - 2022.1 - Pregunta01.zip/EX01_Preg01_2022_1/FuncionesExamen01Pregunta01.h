/* 
 * Proyecto: EX01_Preg01_2022_1
 * Archivo:  FuncionesExamen01Pregunta01.h
 * Autor:    J. Miguel Guanira E.
 *
 * Created on 15 de mayo de 2022, 11:11 AM
 */

#ifndef FUNCIONESEXAMEN01PREGUNTA01_H
#define FUNCIONESEXAMEN01PREGUNTA01_H
#include <fstream>
using namespace std;

void CargarProductosPedidos(int **&, char **&, int**&, const char*);
void PruebaProductosPedidos(int **, char **, int**, const char*);
void leeRegistro(ifstream &,int *&, char *&, int *&);
void imprimeProducto(int, int *,char *,ofstream &);
void imprimePedido(int ,int *,ofstream &);
int buscarProducto(int , int **, int );

void ordenarPedidos(int **);
void qSort(int **,int ,int );
void cambiar(int *&, int *&);
bool enDesorden(int *, int *);

void asignarPedidos(int ***,int **, int**);
int buscarPro(int ,int **);
void agregarPedido(int *,int ***,int *, int*);
int buscarCli(int , int ***);
void colocarPedido(int *,int **,int &,int &);
void aumentarEspacios(int *&, int &, int&);
void ponerPedido(int *,int *, int&);
void imprimePedidos(int *);

#endif /* FUNCIONESEXAMEN01PREGUNTA01_H */

