/* 
 * Proyecto: EX01_Preg01_2022_1
 * Archivo:  FuncionesExamen01Pregunta01.cpp
 * Autor:    J. Miguel Guanira E.
 *
 * Created on 15 de mayo de 2022, 11:11 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include <cstring>
#include "FuncionesExamen01Pregunta01.h"
enum EProd {COD,PU,DES,ST};
enum EPed {DN,FECH,CANT,CODP};

void CargarProductosPedidos(int **&pro_Informacion,
        char **&pro_Descripcion, int**&ped_Todo, const char*nombArch){
    ifstream arch(nombArch, ios::in);
    if (not arch.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }

    int *buffInf[200],*buffPed[200],ndPro=0, ndPed=0, *regProInf, *regPed;
    char *buffproDesc[200],*descripcion;
    
    while(true){
        leeRegistro(arch,regProInf, descripcion, regPed);
        if(arch.eof())break;
        if(buscarProducto(regProInf[COD],buffInf, ndPro) == -1){
             buffInf[ndPro] = regProInf;
             buffproDesc[ndPro] = descripcion;
             ndPro++;
        }
        else{ 
            delete descripcion;
            delete regProInf;
        }
        buffPed[ndPed] = regPed;
        ndPed++;
    }
    pro_Informacion = new int*[ndPro+1];
    pro_Descripcion = new char*[ndPro+1];
    ped_Todo = new int*[ndPed+1];
    for(int i=0; i<ndPro;i++){
        pro_Informacion[i] = buffInf[i];
        pro_Descripcion[i] = buffproDesc[i];
    }
    for(int i=0; i<ndPed;i++)
        ped_Todo[i] =buffPed[i];
    
    pro_Informacion[ndPro] = nullptr;
    pro_Descripcion[ndPro] = nullptr;
    ped_Todo[ndPed] = nullptr;
}
int buscarProducto(int codigo, int **buffInf, int nd){
    for(int i=0; i<nd;i++){
        int *reg = buffInf[i];
        if(reg[COD]==codigo)return i;
    }
    return -1;    
}
void leeRegistro(ifstream &arch,int *&regProInf, char *&descripcion, 
                 int *&regPed){
    
    int cod, dni,dd,mm,aa,codPro;
    double porcent,precU,stock,cantid;
    char descrip[100],c;
    
    arch>>cod;
    if(arch.eof())return;
    regProInf = new int[4];
    regPed = new int [4];
    arch.get();
    regProInf[COD] = cod;
    regPed[CODP] = cod;
    arch.getline(descrip,100,',');
    descripcion = new char[strlen(descrip)+1];
    strcpy(descripcion,descrip);
    
    arch>>porcent;                        //{COD,PU,DES,ST}
    if(arch.get()=='%'){                  //{DN,FECH,CANT,CODP}
        regProInf[DES] = (int)(porcent*100);
        arch.get();
        arch>>cantid;
        regPed[CANT] = (int)(cantid*100);
        arch.get();
    }
    else{
        regPed[CANT] = (int)(porcent*100);
        regProInf[DES] = 0;           
    }
    
    arch>>precU;
    arch.get();
    regProInf[PU] = (int)(precU*100);   
    arch>>stock;
    arch.get();
    regProInf[ST] = (int)(stock*100);
    arch>>dni;
    arch.get();
    regPed[DN] = dni;
    arch>>dd>>c>>mm>>c>>aa;
    regPed[FECH] = aa*10000+mm*100+dd;
}    


void PruebaProductosPedidos(int **pro_Informacion,
        char **pro_Descripcion, int**ped_Todo, const char*nombArch){
    ofstream arch(nombArch, ios::out);
    arch.precision(2);
    arch<<fixed;
    if (not arch.is_open()){
        cout<<"ERROR: No se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
    arch<<"PRODUCTOS"<<endl;
    for(int i=0; pro_Informacion[i]; i++)
        imprimeProducto(i+1,pro_Informacion[i],pro_Descripcion[i],arch);
    arch<<"PEDIDOS"<<endl;
    for(int i=0; ped_Todo[i]; i++)
        imprimePedido(i+1,ped_Todo[i],arch); 
}
//{COD,PU,DES,ST} //{DN,FECH,CANT,CODP}
void imprimeProducto(int n,int *pro_Informacion,char *pro_Descripcion,
                      ofstream &arch){
     arch<<left<<setw(5)<<n<<setw(10)<<pro_Informacion[COD]
         <<setw(50)<<pro_Descripcion<<right<<setw(10)<<pro_Informacion[PU]
         <<setw(10)<<pro_Informacion[DES]<<setw(10)<<pro_Informacion[ST]<<endl;   
}
   
void imprimePedido(int n, int *ped_Todo,ofstream &arch){
    arch<<right<<setw(3)<<n<<setw(10)<<ped_Todo[DN]<<setw(10)<<ped_Todo[FECH]
        <<setw(10)<<ped_Todo[CANT]<<setw(10)<<ped_Todo[CODP]<<endl;    
}

void ordenarPedidos(int **ped_Todo){
    int nd;
    for(nd=0 ; ped_Todo[nd]; nd++);
    qSort(ped_Todo,0,nd-1);  
}

void qSort(int **ped_Todo,int izq,int der){
    int limite;
    if(izq >= der) return;
    // Ponemos el elemento "pivot" al inicio
    cambiar(ped_Todo[izq], ped_Todo[(izq+der)/2]);
    limite = izq;
    for(int i = izq+1; i<=der; i++)
        if(enDesorden(ped_Todo[i],ped_Todo[izq]))
            cambiar(ped_Todo[++limite], ped_Todo[i]);
   cambiar(ped_Todo[izq], ped_Todo[limite]);
   qSort(ped_Todo,izq,limite-1);
   qSort(ped_Todo,limite+1,der);    
}

void cambiar(int *&valorI, int *&valorK){
    int *aux;
    aux = valorI;
    valorI = valorK;
    valorK = aux;   
}

bool enDesorden(int *vI, int *vK){   
    return vI[FECH]<vK[FECH] or vI[FECH] == vK[FECH] and vI[DN]<vK[DN];
}

//{COD,PU,DES,ST} //{DN,FECH,CANT,CODP}
void asignarPedidos(int ***cli_DniTelPed,int **pro_Informacion, int**ped_Todo){
    int *ped, posPro, *prod;
    int nd[200]{}, cap[200]{};
    
    for(int i=0; ped_Todo[i]; i++){
        ped = ped_Todo[i];
        posPro = buscarPro(ped[CODP],pro_Informacion);
        if(posPro!=-1) {
            prod = pro_Informacion[posPro];
            if (prod[ST]>ped[CANT]){
                prod[ST]-= ped[CANT];
                agregarPedido(ped,cli_DniTelPed,nd,cap);
            }
         }
    }
}

int buscarPro(int codPro,int **pro_Informacion){
    for(int i=0; pro_Informacion[i]; i++){
        int *pro = pro_Informacion[i];
        if(pro[COD] == codPro) return i;
    }
    return -1;
}

void agregarPedido(int *ped,int ***cli_DniTelPed,int *nd, int*cap){
    int  posCli;
    
    posCli = buscarCli(ped[DN],cli_DniTelPed);
    if(posCli!=-1)
        colocarPedido(ped,cli_DniTelPed[posCli],nd[posCli],cap[posCli]);   
}

int buscarCli(int ped, int ***cli_DniTelPed){
    for(int i=0; cli_DniTelPed[i]; i++){
        int **cli = cli_DniTelPed[i];
        if(ped == *cli[0]) return i;
    }
    return -1;
}

//{COD,PU,DES,ST} //{DN,FECH,CANT,CODP}
void colocarPedido(int *ped,int **cli_DniTelPed,int &nd,int &cap){
    if (nd == cap) aumentarEspacios(cli_DniTelPed[2], nd, cap);
    ponerPedido(ped,cli_DniTelPed[2], nd);
}

void aumentarEspacios(int *&cli_DniTelPed, int &nd, int&cap){
    int*aux;
    
    cap += 15;
    if (cli_DniTelPed == nullptr){
        cli_DniTelPed = new int[cap];
        cli_DniTelPed[0] = 0;
        cli_DniTelPed[1] = 0;
        cli_DniTelPed[2] = 0;
        nd = 3;
    }
    else{
        aux = new int[cap];
        for(int i=0; i<nd; i++){
            aux[i] = cli_DniTelPed[i];
        }
        delete cli_DniTelPed;
        cli_DniTelPed = aux;
    }
}

void ponerPedido(int *ped,int *cli_DniTelPed, int&nd){
    cli_DniTelPed[nd] = 0;
    cli_DniTelPed[nd-1] = ped[CANT];
    cli_DniTelPed[nd-2] = ped[CODP];
    cli_DniTelPed[nd-3] = ped[FECH];
    nd+=3;
}