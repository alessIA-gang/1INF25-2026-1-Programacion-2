/* 
 * Proyecto: EX01_Preg01_2022_1
 * Archivo:  main.cpp
 * Autor:    J. Miguel Guanira E E. 
 *
 * Created on 15 de mayo de 2022, 10:33 AM
 */

#include "ClientesPreg1.h"
#include "FuncionesExamen01Pregunta01.h"

int main(int argc, char** argv) {
    char ***cli_NombreCategoria, **pro_Descripcion;    
    int ***cli_DniTelPed,        **pro_Informacion, **ped_Todo;
    
    CargaDeClientes(cli_DniTelPed,cli_NombreCategoria,"ClientesPreg01.csv");
    PruebaDeClientes(cli_DniTelPed,cli_NombreCategoria,"PreubaClientes01x.txt");
    
    CargarProductosPedidos(pro_Informacion,pro_Descripcion,ped_Todo,
                           "PedidosPreg01.csv");
    PruebaProductosPedidos(pro_Informacion,pro_Descripcion,ped_Todo,
                           "PruebaProductosClientes01.txt");
    
    ordenarPedidos(ped_Todo);
    PruebaProductosPedidos(pro_Informacion,pro_Descripcion,ped_Todo,
                           "PruebaProductosClientes02.txt");
    
    asignarPedidos(cli_DniTelPed,pro_Informacion,ped_Todo);
    
    PruebaDeClientes(cli_DniTelPed,cli_NombreCategoria,"PreubaClientes02.txt");
    return 0;
}

