/* 
 * Proyecto: Examen01_Pregunta01_2023-1
 * Archivo:  Preg1_Funciones_de_cursos_y_alumnos.h
 * Autor:    J. miguel.guanira.
 *
 * Created on 23 de mayo de 2023, 10:56 AM
 */

#ifndef PREG1_FUNCIONES_DE_CURSOS_Y_ALUMNOS_H
#define PREG1_FUNCIONES_DE_CURSOS_Y_ALUMNOS_H
#include <fstream>
using namespace std;

void cargarCursosYEscalas(char***&,double *&,double *,const char*,const char*);
void pruebaDeCargaDeCursos(char ***,double *, const char* );
void cargarAlumnos(int *&,int **&,char ***&,  const char*);
void pruebaDeCargaDeAlumnos(int *, int **, char ***,const char*);
void leerCursos(char ***&,double *&, ifstream&);
void leerEscalas(double *,ifstream&);
void aumentarEspacios(char ***&,double *&,int &,int &);
char **leeCurso(ifstream &,double &);
char *leeCadena(ifstream &,char = '\n');
void imprimeCurso(ofstream &, char **, double);
int leeAlumno(ifstream &,int *&, char **&);
void leeDatosAlum(ifstream &,int &, int &, int &, char *&, char &);
void aumentarEspacios(int*&,int**&,char***&, int &,int &);
char imprimirAlumnosNombMod(ofstream &,char **);
void imprimirAlumnosCodEscPorc(ofstream &,int *,char );
void probarCargaEscala(double *); // Esto no se pide

#endif /* PREG1_FUNCIONES_DE_CURSOS_Y_ALUMNOS_H */

