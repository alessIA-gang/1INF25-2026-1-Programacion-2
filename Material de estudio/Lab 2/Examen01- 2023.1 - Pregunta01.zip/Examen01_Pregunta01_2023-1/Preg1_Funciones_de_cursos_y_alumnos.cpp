/* 
 * Proyecto: Examen01_Pregunta01_2023-1
 * Archivo:  Preg1_Funciones_de_cursos_y_alumnos.cpp
 * Autor:    J. miguel.guanira.
 *
 * Created on 23 de mayo de 2023, 10:56 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;
#include <cstring>
#include "AperturaDeArchivos.h"
#include "Preg1_Funciones_de_cursos_y_alumnos.h"
#define INCREMENTO 5
enum RegCur {CODCUR, NOMCUR, NOMPRO};
enum RegAlumInt {CODALU, ESCALA, PORCENT};

void cargarCursosYEscalas(char ***&cursos,double *&cursos_cred,double *escalas,
                          const char*nombArchCursos,const char*nombArchEscalas){
    ifstream archCursos, archEscalas;
    AperturaDeUnArchivoDeTextosParaLeer(archCursos,nombArchCursos);
    AperturaDeUnArchivoDeTextosParaLeer(archEscalas,nombArchEscalas);
    
    cursos = nullptr;
    cursos_cred = nullptr;
    leerCursos(cursos,cursos_cred, archCursos);
    leerEscalas(escalas,archEscalas);
    
}

void leerCursos(char ***&cursos,double *&cursos_cred, ifstream&archCursos){
    double creditos;
    char **registro;
    int numDat = 0, capacidad = 0;
    cursos = nullptr;
    cursos_cred = nullptr;
    while(true){
        registro = leeCurso(archCursos,creditos);
        if(archCursos.eof())break;
        if(numDat==capacidad)
            aumentarEspacios(cursos,cursos_cred,numDat,capacidad);
        cursos[numDat] = nullptr;
        cursos[numDat-1] = registro;
        cursos_cred[numDat] = -1; // es un double y NO se puede usar =
        cursos_cred[numDat-1] = creditos;   
        numDat++;
    }
}

char **leeCurso(ifstream &archCursos,double &creditos){
    //INF263,Algoritmia,3.75,35030611,INGA FLORES CESAR ADOLFO
    char c, **curso, *codCurso, *nombCurso, *nombProf, nomb[60];
    int codProf;
    
    codCurso = leeCadena(archCursos,',');
    if(archCursos.eof())return nullptr;
    nombCurso = leeCadena(archCursos,',');
    archCursos>>creditos>>c>>codProf>>c;
    nombProf = leeCadena(archCursos);
    curso = new char*[3];
    curso[CODCUR] = codCurso;
    curso[NOMCUR] = nombCurso;
    curso[NOMPRO] = nombProf;
    return curso;
}

void aumentarEspacios(char ***&cursos,double *&cursos_cred,int &numDat,
                      int &capacidad){
    char ***auxCur;
    double *auxCred;
    capacidad += INCREMENTO;
    if(cursos == nullptr){
        cursos = new char**[capacidad];
        cursos_cred = new double[capacidad];
        cursos[0] = nullptr;
        cursos_cred[0] = -1.0;
        numDat=1;
    }
    else{
        auxCur = new char**[capacidad];
        auxCred = new double[capacidad];
        for(int i=0; i<numDat; i++){
            auxCur[i] = cursos[i];
            auxCred[i] = cursos_cred[i];
        }
        delete cursos;
        delete cursos_cred;
        
        cursos = auxCur;
        cursos_cred = auxCred;
    }
}

void leerEscalas(double *escalas,ifstream&archEscalas){
    //G5,666.90
    int escalaPosicion;
    double escalaValor;
    char c;
    for(int i=0; i<5; i++){
        archEscalas>>c>>escalaPosicion>>c>>escalaValor;
        escalaPosicion--;
        escalas[escalaPosicion] = escalaValor;
    }
    probarCargaEscala(escalas); // Esto no se pide
}

void probarCargaEscala(double *escalas){ // Esto no se pide
    cout.precision(2);
    cout<<fixed;
    for (int i=0; i<5; i++)
        cout<<setw(10)<<escalas[i]<<endl;
}

void pruebaDeCargaDeCursos(char ***cursos,double *cursos_cred,
                           const char* nomArchRepCursos){
    ofstream archRepCursos;
    AperturaDeUnArchivoDeTextosParaEscribir(archRepCursos,nomArchRepCursos);
    for(int i=0; cursos[i]; i++)
        imprimeCurso(archRepCursos, cursos[i],cursos_cred[i]);
}

void imprimeCurso(ofstream &archRepCursos, char **cursos, double creditos){
    archRepCursos.precision(2);
    archRepCursos<<fixed;
    
    archRepCursos<<left<<setw(8)<<cursos[CODCUR]<<setw(55)<<cursos[NOMCUR]
                 <<right<<setw(5)<<creditos<<"   "
                 <<left<<setw(45)<<cursos[NOMPRO]<<endl;
}

    
void cargarAlumnos(int *&alumnos_cod,int **&alumnos,char ***&alumnos_nom_mod,
                   const char*nombArchAlumnos){
    ifstream archAlumnos;
    AperturaDeUnArchivoDeTextosParaLeer(archAlumnos,nombArchAlumnos);
    int codAlum, *regAlumNum;
    char **regAlumTex;
    int numDat = 0, capacidad = 0;
    alumnos_cod = nullptr;
    alumnos = nullptr;
    alumnos_nom_mod = nullptr;
    while(true){
        codAlum = leeAlumno(archAlumnos,regAlumNum, regAlumTex);
        if(archAlumnos.eof())break;
        if(numDat==capacidad)
            aumentarEspacios(alumnos_cod,alumnos,alumnos_nom_mod,
                             numDat,capacidad);
        alumnos_cod[numDat] = 0;
        alumnos[numDat] = nullptr;
        alumnos_nom_mod[numDat] = nullptr;        
        alumnos_cod[numDat-1] = codAlum;
        alumnos[numDat-1] = regAlumNum; 
        alumnos_nom_mod[numDat-1] = regAlumTex;   
        numDat++;
    }
}

int leeAlumno(ifstream &archAlumnos,int *&regAlumNum, char **&regAlumTex){
    //202123703,GAMARRA TABORI PAUL RONAL,S,30,G5
    int codAlum, porc, escala;
    char *nomAlum, mod;
    
    leeDatosAlum(archAlumnos,codAlum, porc, escala,nomAlum, mod);
    if(archAlumnos.eof())return 0;
    
    if(mod == 'S') {
        regAlumNum = new int[3];
        regAlumNum[CODALU] = codAlum;
        regAlumNum[ESCALA] = escala;
        regAlumNum[PORCENT] = porc;        
    }
    else{
        regAlumNum = new int[2];
        regAlumNum[CODALU] = codAlum;
        regAlumNum[ESCALA] = escala;
    }
    
    regAlumTex = new char*[2];
    regAlumTex[0] = nomAlum;
    regAlumTex[1] = new char {mod};
    return codAlum;
}

void leeDatosAlum(ifstream &archAlumnos, int &codAlum, int &porc, int &escala, 
                  char *&nomAlum, char &mod){
    //202123703,GAMARRA TABORI PAUL RONAL,S,30,G5
    //202123703,GAMARRA TABORI PAUL RONAL,V,G5
    //202123703,GAMARRA TABORI PAUL RONAL,G5
    char c;
    archAlumnos>>codAlum;
    if(archAlumnos.eof())return;
    archAlumnos.get(); //saco la coma
    nomAlum = leeCadena(archAlumnos,',');
    archAlumnos>>mod;
    if (mod == 'S') 
        archAlumnos>>c>>porc>>c>>c; // lee: ,30,G    
    else if(mod=='V') 
        archAlumnos>>c>>c;          // lee: ,G
    else 
        mod = 'P';                  // leyó la G
    archAlumnos>>escala;
}

void aumentarEspacios(int*&alumnos_cod,int**&alumnos,char***&alumnos_nom_mod,
                      int &numDat,int &capacidad){
    int *auxAlCod, **auxAl;
    char ***auxNomMod;
    
    capacidad += INCREMENTO;
    if(alumnos_cod == nullptr){
        alumnos_cod = new int[capacidad];
        alumnos = new int*[capacidad];
        alumnos_nom_mod = new char **[capacidad];
        alumnos_cod[0] = 0;
        alumnos[0] = nullptr;
        alumnos_nom_mod[0] = nullptr;
        numDat=1;
    }
    else{
        auxAlCod = new int[capacidad];
        auxAl = new int *[capacidad];
        auxNomMod = new char **[capacidad];
        for(int i=0; i<numDat; i++){
            auxAlCod[i] = alumnos_cod[i];
            auxAl[i] = alumnos[i];
            auxNomMod[i] = alumnos_nom_mod[i];
        }
        delete alumnos_cod;
        delete alumnos;
        delete alumnos_nom_mod;
        
        alumnos_cod = auxAlCod;
        alumnos = auxAl;
        alumnos_nom_mod = auxNomMod;
    }
}

char *leeCadena(ifstream &archCursos,char separador){
    char *cadena, cad[100];
    archCursos.getline(cad,100,separador);
    if(archCursos.eof())return nullptr;
    cadena = new char[strlen(cad)+1];
    strcpy(cadena,cad);
    return cadena;
}

void pruebaDeCargaDeAlumnos(int *alumnos_cod, int **alumnos, 
                      char ***alumnos_nom_mod,const char*nombArchRepAlumnos){
    ofstream archRepAlumnos;
    AperturaDeUnArchivoDeTextosParaEscribir(archRepAlumnos,nombArchRepAlumnos);
    char modalidad;
    for(int i=0; alumnos_cod[i]; i++){
        archRepAlumnos<<right<<setw(10)<<alumnos_cod[i];
        modalidad = imprimirAlumnosNombMod(archRepAlumnos,alumnos_nom_mod[i]);
        imprimirAlumnosCodEscPorc(archRepAlumnos,alumnos[i],modalidad);
        archRepAlumnos<<endl;
    }
}

char imprimirAlumnosNombMod(ofstream &archRepAlumnos, char **alumnos){
    archRepAlumnos<<left<<"     "<<setw(40)<<alumnos[0]<<setw(5)<<*alumnos[1];
    return *alumnos[1];
}

void imprimirAlumnosCodEscPorc(ofstream &archRepAlumnos,int *alumnos,
                                                           char modalidad){
    archRepAlumnos<<right<<setw(10)<<alumnos[CODALU]
                         <<setw(3) <<alumnos[ESCALA];
    if(modalidad=='S') archRepAlumnos<<setw(5)<<alumnos[PORCENT];
}
