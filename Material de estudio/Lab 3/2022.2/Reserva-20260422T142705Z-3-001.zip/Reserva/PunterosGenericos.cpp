/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PunterosGenericos.cpp
 * Author: cueva
 * 
 * Created on 6 de octubre de 2022, 10:17 PM
 */
#include <iostream>
#include <fstream>
#include <cstring>
#include "PunterosGenericos.h"
#include "FuncionesAuxiliares.h"

using namespace std;

/*
60509,AMPICILINA 125MG SUSP 90ML,58.65,37
73972,VITAMINA E 400 MG C90 CAPS,54.4,45
94429,TIAMAZOL 5MG 20T,52.7,13
 
 */

void *leemedicinas(ifstream &arch){
    int cod,*codigo,*stock;
    char desc[200],c,*nombre;
    double *precio,*reserva;
    void**reg,**pedidos;
    
    arch >> cod;
    if(arch.eof()) return NULL;
    codigo = new int;
    *codigo = cod;
    arch >> c;
    arch.getline(desc,200,',');
    nombre = new char[strlen(desc)+1];
    strcpy(nombre,desc);
    precio = new double;
    reserva = new double;
    stock = new int;
    arch >> *precio >> c >> *stock;
    arch.get();
    *reserva = 0;
    reg = new void*[5];

    reg[0] = codigo;
    reg[1] = nombre;
    reg[2] = precio;
    reg[3] = stock;
    reg[4] = reserva;

   // pedidos = new void*[*stock]{};
   // reg[5] = pedidos;
    
    return reg;
}

void cargamedicinas(void *&medicinas){
    void **lmedicinas;
    void *buffer[300];
    int i=0;
    ifstream arch("medicinas.csv",ios::in);
    if(!arch){
       cout << "No se puede cargar las medicinas"; 
       exit(1);
    }
    while(1){
        buffer[i]=leemedicinas(arch);
        if(!buffer[i])break;
        i++;
    }    
    lmedicinas = new void*[i+1];    
    for(int j=0;j<=i;j++){
        lmedicinas[j]=buffer[j];     
    }    
    medicinas = lmedicinas;
    imprimemedicinas(medicinas);
}
/*
LZ53556,32538825,Hijar/Martin,1/09/2022,4,92560,11,16681,35,47697,7,26506,14
LZ53557,85395219,Fuentes/Patricia,29/12/2022,5,30428,31,33311,15,57505,23,52072,15,22232,30
 
 */

void *cargareceta(ifstream &arch,int cant){
    int *codigo,*pedido;
    char c,*estado;
    void **lreg,**reg;
    
    lreg = new void*[cant];
    for(int i=0;i<cant;i++){
        reg = new void*[3];
        codigo = new int;
        pedido = new int;
        estado = new char;
        arch >> *codigo >> c >> *pedido>>c;
        *estado = 'S';
        reg[0] = codigo;
        reg[1] = pedido;
        reg[2] = estado;
        lreg[i] = reg;
    }
    
    return lreg;
    
}

void *leeconsultas(ifstream &arch){
    int *cant,*codigo,*stock,*dni,*fecha,dd,mm,aa;
    char coddoc[20],desc[200],c,*nombre;
    double *precio;
    void**reg;
    
    arch.getline(coddoc,20,',');
    if(arch.eof()) return NULL;
    dni = new int;
    arch >>*dni >> c ;
    arch.getline(desc,200,',');
    nombre = new char[strlen(desc)+1];
    strcpy(nombre,desc);
    cant = new int;
    arch >> dd >>c >> mm >>c >>aa>> c >> *cant >> c;
    fecha = new int;
    *fecha=aa*10000+mm*100+dd;
    reg = new void*[5];

    reg[0] = dni;
    reg[1] = nombre;
    reg[2] = cant;
    reg[3] = cargareceta(arch,*cant);
    reg[4] = fecha;
    //arch.get();
    return reg;
}

void cargaconsultas(void *&citas){
    void **lcitas;
    void *buffer[300];
    int i=0;
    ifstream arch("consultas.csv",ios::in);
    if(!arch){
       cout << "No se puede cargar las consultas"; 
       exit(1);
    }
    while(1){
        buffer[i]=leeconsultas(arch);
        if(!buffer[i])break;
        i++;
    }    
    lcitas = new void*[i+1];    
    for(int j=0;j<=i;j++){
        lcitas[j]=buffer[j];     
    }    
    citas = lcitas;

}

void buscaactualiza(void *medicinas,void*linea,int dni,char *nombre,int fecha){
    void **lmedicinas = (void**)medicinas;
    int i=0,*codmed,*codped,*stock,*reserva,*cantped;
    char *estado;
    
    while(lmedicinas[i]){
        void**reg=(void**)lmedicinas[i];
        void**aux=(void**)linea;
        codmed=(int*)reg[0];
        codped=(int*)aux[0];
        cantped=(int*)aux[1];
        estado=(char*)aux[2];
        if(*codmed==*codped){
            stock = (int*)reg[3];
            reserva = (int*)reg[4];
            if(*stock-*reserva-*cantped>=0){
                *reserva = *reserva+*cantped;
                *estado = 'R';
            }
            break;
        }
        i++;
    }
}

void actualizareservas(void *&medicinas,void *citas){
    int i=0,*dni,*fecha,*cant;
    char *nombre;
    void **reg,**receta;
    ordenareservas(citas);

    void **lcitas=(void**)citas;
    
    while(lcitas[i]){
        reg=(void**)lcitas[i];
        
        dni = (int*)reg[0];
        nombre = (char*)reg[1];
        cant = (int*)reg[2];
        receta = (void**)reg[3];
        fecha = (int*)reg[4];
        
        for(int i=0;i<*cant;i++){
            void**linea=(void**)receta[i];
            buscaactualiza(medicinas,linea,*dni,nombre,*fecha);
        }
        i++;
    }
    
    imprimeconsultas(citas);
    
}




