/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PunterosGenericos.h
 * Author: cueva
 *
 * Created on 6 de octubre de 2022, 10:17 PM
 */

#ifndef PUNTEROSGENERICOS_H
#define PUNTEROSGENERICOS_H
    void cargamedicinas(void *&);
    void cargaconsultas(void *&);
    void actualizareservas(void *&,void *);
#endif /* PUNTEROSGENERICOS_H */
