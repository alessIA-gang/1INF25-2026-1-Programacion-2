/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: cueva
 *
 * Created on 6 de octubre de 2022, 10:08 PM
 */

#include "FuncionesAuxiliares.h"
#include "PunterosGenericos.h"

using namespace std;

int main(int argc, char** argv) {
    void *medicinas,*citas;
    
    cargamedicinas(medicinas);
    cargaconsultas(citas);
    actualizareservas(medicinas,citas);
    imprimerepfinal(citas);
    return 0;
}

