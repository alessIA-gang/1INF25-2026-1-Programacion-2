/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: cueva
 *
 * Created on 11 de mayo de 2023, 11:12 AM
 */

#include "FuncionesMemoria.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int *codigos;
    CargaAlumno(codigos,"codigos.csv");
    
    return 0;
}

