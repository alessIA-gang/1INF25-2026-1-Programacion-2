/* 
 * File:   main.cpp
 * Author: cueva
 *
 * Created on 11 de mayo de 2023, 03:51 PM
 */

#include "PunterosGenericos.h"
#include "FuncionesMemoria.h"
#include "FuncionesAuxiliares.h"

using namespace std;

int main(int argc, char** argv) {
    int *alumnos_cod;
    void *alumnoveces;
    
    cargarAlumnos(alumnos_cod,"Alumnos.csv");
    CargaCursos(alumnos_cod,alumnoveces,"matricula.csv");
    //ActualizaVeces(alumnoveces);
    ImprimeAlumno(alumnoveces);
    return 0;
}

