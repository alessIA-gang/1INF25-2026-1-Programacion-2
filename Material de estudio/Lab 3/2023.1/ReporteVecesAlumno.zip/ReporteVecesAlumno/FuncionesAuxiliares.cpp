/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   FuncionesAuxiliares.cpp
 * Author: cueva
 * 
 * Created on 11 de mayo de 2023, 09:52 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include "FuncionesAuxiliares.h"

using namespace std;


void imprimelinea(ofstream &arch,void*linea,int n){
    void **llinea = (void**)linea;
    int i,*nota,*ciclo;
    char *codcur;
    
    for(i=0;i<n;i++){
        void**reg=(void**)llinea[i];
        codcur=(char*)reg[0];
        ciclo=(int*)reg[1];
        nota=(int*)reg[2];
        arch << setw(2) << i+1<<setw(10)<<codcur<<setw(10)<<*ciclo
                <<setw(5)<<*nota<<endl; 
        
    }
    arch << endl;    
}


void imprimealumnoreg(ofstream &arch,void *registro){
    void **laux = (void**)registro;
    int *codigo,*ncursos,*naprobados,*nprimera,*nsegunda,
        *ntercera;
   
    codigo = (int*)laux[0];
    ncursos = (int*)laux[1];
    naprobados = (int*)laux[2];
    nprimera = (int*)laux[3];
    nsegunda = (int*)laux[4];
    ntercera = (int*)laux[5];    
    
    arch <<"Codigo de Alumno:" <<setw(20)<< *codigo <<endl;
    arch <<"Detalle de Cursos:"<<endl;
    arch <<"Cursados Aprobados  1ra Vez   2da Vez   3ra Vez " <<endl;  
    arch << setw(5)<< *ncursos << 
        setw(10)<< *naprobados<<setw(10)<<*nprimera<<
        setw(10)<< *nsegunda<<setw(10)<<*ntercera<< endl;
    if(*ncursos>0){
        arch << "Cursos matriculados:" << endl;
        imprimelinea(arch,laux[6],*ncursos);
    }   
    else
        arch << endl;
    arch << endl;
}


void ImprimeAlumno(void *alumno){
    int i=0;
    void **laux = (void**)alumno;
    ofstream arch("repalumno.txt",ios::out);
    if(!arch){
        cout << "No se puede leer Reporte Alumno";
        exit(1);
    }

    while(1){
        if(laux[i]==NULL) break; 
        imprimealumnoreg(arch,laux[i]);
        i++;
    }
      
}