/* 
 * File:   PunterosGenericos.cpp
 * Author: cueva
 * 
 * Created on 11 de mayo de 2023, 03:53 PM
 */
#include <cstring>
#include <fstream>
#include <iostream>
#include "PunterosGenericos.h"
#include "FuncionesAuxiliares.h"

using namespace std;

void Inicializa(int *alumnos,void *&alumnoveces){
    int *codigo,*ncursos,*naprobados,*nprimera,*nsegunda,i,*ntercera;
    void**reg,*buffer[300],**lveces;
    
    for(i=0;alumnos[i]!=0 && alumnos[i]!=-1;i++){
        reg = new void*[8];
        codigo = new int; ncursos = new int; naprobados = new int;
        nprimera = new int; nsegunda = new int; ntercera = new int;
        
        *codigo = alumnos[i];*ncursos = 0; *naprobados=0; *nprimera = 0; *nsegunda = 0;*ntercera = 0; 
        
        reg[0] = codigo;
        reg[1] = ncursos;
        reg[2] = naprobados;
        reg[3] = nprimera;
        reg[4] = nsegunda;
        reg[5] = ntercera;
        reg[6] = nullptr;
        buffer[i] = reg;
    }
    buffer[i] = nullptr;
    
    lveces = new void*[i+1];    
    for(int j=0;j<=i;j++){
        lveces[j]=buffer[j];     
    }    
    alumnoveces = lveces;
}

int busca(int codigo,int *alumnos){
    int i;
    for(i=0;alumnos[i]!=0 && alumnos[i]!=-1 && alumnos[i]!=codigo;i++);
    return i;
}

void CargaVez(int indcurso,char *codclave,int *ciclo,int *nota,void *&cursos){
    void **lcursos = (void**)cursos;
    void **reg;
    
    reg = new void*[3];
    reg[0] = codclave;
    reg[1] = ciclo;
    reg[2] = nota;    
    lcursos[indcurso] = reg;   
}

/*
202123703,MEC270,202302,14
202315643,MEC270,202202,13
202312000,MEC206,202301,8
202318383,INF246,202202,16
*/
void leematricula(ifstream &arch,void *alumno){
    int *nota,*ciclo,*indcurso;
    char clave[10],c,*codclave;
    void **lcurso,**lalumno=(void**)alumno;
    
    arch.getline(clave,10,',');
    codclave = new char[strlen(clave)+1];
    strcpy(codclave,clave);
    ciclo = new int; nota = new int;
    arch >> *ciclo >> c >> *nota;
    indcurso = (int*)lalumno[1];
    if (*indcurso==0){
        lcurso = new void*[200];
        lalumno[6] = lcurso;
    }
    CargaVez(*indcurso,codclave,ciclo,nota,lalumno[6]);
    *indcurso = *indcurso +1 ;
}

void CargaCursos(int *alumnos,void *&alumnoveces,const char*nombArch ){
    int codigo,ind;
    ifstream arch(nombArch,ios::in);
    if(!arch){
       cout << "No se puede cargar las matriculas"; 
       exit(1);}

    Inicializa(alumnos,alumnoveces);
    void **lveces = (void**)alumnoveces;
    while(1){
        arch >> codigo;
        if(arch.eof()) break;
        arch.get();
        ind=busca(codigo,alumnos);
        leematricula(arch,lveces[ind]);
    }   
    Recorta(alumnoveces);
}


void recortanivel(void *&cursos,int cant){
    void **lcursos = (void**)cursos;
    void **matricula;
    
    matricula = new void*[cant];
    for(int i=0;i<cant;i++){
        matricula[i] = lcursos[i];
    }
    cursos = matricula;
    delete[] lcursos;
}

void Recorta(void *alumnoveces){
    void **lalumno = (void**)alumnoveces;
    void **regalu;
    int *cant;
    
    for(int i=0;lalumno[i]!=nullptr;i++){
        regalu = (void**)lalumno[i];
        cant = (int*)regalu[1];
        recortanivel(regalu[6],*cant);
    }
       
}



int cuentavez(char *codclave,int n,void*lista){
    char *clave;
    int cont=0;
    void **lcursos=(void**)lista;
    for(int i=0;i<n;i++){
        void **reg = (void**)lcursos[i];
        clave = (char*)reg[0];
        if(strcmp(codclave,clave)==0)
            cont++;
    }
    return cont;
}

void procesaveces(void* veces){
    int nvez,*ncursos,*naprobados,*nprimera,*nsegunda,i,*ntercera,*ciclo,*nota;
    char *codclave;
    void ** reg,**lveces = (void**)veces;
    void**lcursos = (void**)lveces[6];
    ncursos = (int*)lveces[1];
    naprobados = (int*)lveces[2];
    nprimera = (int*)lveces[3];
    nsegunda = (int*)lveces[4];
    ntercera = (int*)lveces[5];
    
    for(int i=0;i<*ncursos;i++){
        reg = (void**)lcursos[i];
        nota = (int*)reg[2];
        if(*nota>10){
            codclave = (char*)reg[0];
            nvez = cuentavez(codclave,*ncursos,lveces[6]);
            if(nvez==1) *nprimera = *nprimera + 1;
            if(nvez==2) *nsegunda = *nsegunda +1;
            if(nvez==3) *ntercera = *ntercera + 1;
            *naprobados = *naprobados + 1;
        }
    }
}

void ActualizaVeces(void *alumnoveces){
    int i=0;
    void **lveces=(void**)alumnoveces;
    
    while(1){
        if(lveces[i]==nullptr) break;
        procesaveces(lveces[i]);
        i++;
    }
    
    
}
