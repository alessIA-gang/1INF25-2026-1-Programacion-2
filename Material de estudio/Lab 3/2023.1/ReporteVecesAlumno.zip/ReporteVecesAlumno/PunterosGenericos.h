/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   PunterosGenericos.h
 * Author: cueva
 *
 * Created on 11 de mayo de 2023, 03:53 PM
 */

#ifndef PUNTEROSGENERICOS_H
#define PUNTEROSGENERICOS_H
    void CargaCursos(int * ,void *&,const char* );
    void ActualizaVeces(void *);
    void Recorta(void *alumnoveces);
#endif /* PUNTEROSGENERICOS_H */
